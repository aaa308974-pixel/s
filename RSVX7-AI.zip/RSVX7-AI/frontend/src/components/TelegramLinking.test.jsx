import React, { act } from "react";
import { createRoot } from "react-dom/client";
import Register from "@/pages/Register";
import TelegramGate from "./TelegramGate";

const mockRegister = jest.fn();
const mockActivate = jest.fn();
const mockAuthFetch = jest.fn();
const mockRefresh = jest.fn();
const mockLogout = jest.fn();
jest.mock("@/context/AuthContext", () => ({ useAuth: () => ({ user: { _id: "user1", username: "new_user", role: "user" }, register: mockRegister, activateSession: mockActivate, authFetch: mockAuthFetch, refresh: mockRefresh, logout: mockLogout }) }));
jest.mock("@/components/chat/Logo", () => () => <div />);
jest.mock("sonner", () => ({ toast: { success: jest.fn(), error: jest.fn() } }));
jest.mock("framer-motion", () => ({ motion: { div: ({ initial, animate, ...props }) => require("react").createElement("div", props) } }));
jest.mock("@/components/ui/button", () => ({ Button: (props) => require("react").createElement("button", props) }));
jest.mock("@/components/ui/input", () => ({ Input: (props) => require("react").createElement("input", props) }));
jest.mock("@/components/ui/label", () => ({ Label: (props) => require("react").createElement("label", props) }));
const reply = (json, ok = true) => ({ ok, json: async () => json });
const link = () => ({ deep_link: "https://t.me/Test_bot?start=test-nonce", telegram_bot_username: "Test_bot", expires_at: new Date(Date.now() + 600000).toISOString(), telegram_bot_configured: true });
let container, root;
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  [mockRegister, mockActivate, mockAuthFetch, mockRefresh, mockLogout].forEach((fn) => fn.mockReset());
  mockRefresh.mockResolvedValue({}); mockActivate.mockResolvedValue({ _id: "user1" });
  global.fetch = jest.fn();
  container = document.createElement("div"); document.body.appendChild(container); root = createRoot(container);
});
afterEach(async () => { await act(async () => root.unmount()); container.remove(); });
async function input(id, value) {
  await act(async () => {
    const element = container.querySelector(`[data-testid="${id}"]`);
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(element, value);
    element.dispatchEvent(new Event("input", { bubbles: true }));
  });
}
async function registerAccount(configured = true) {
  mockRegister.mockResolvedValue({ token: "registration-test-token", recovery_code: "TEST-CODE" });
  fetch.mockResolvedValue(reply({ ...link(), telegram_bot_configured: configured }));
  await act(async () => root.render(<Register />));
  await input("reg-username", "new_user"); await input("reg-password", "TestPassword1");
  await act(async () => container.querySelector("form").dispatchEvent(new Event("submit", { bubbles: true, cancelable: true })));
}

test("private link appears next to recovery code before session activation", async () => {
  await registerAccount();
  expect(container.querySelector('[data-testid="recovery-code"]').textContent).toBe("TEST-CODE");
  expect(container.querySelector('[data-testid="register-telegram-link"]').href).toBe(link().deep_link);
  expect(mockActivate).not.toHaveBeenCalled();
  expect(fetch.mock.calls[0][1].headers.Authorization).toBe("Bearer registration-test-token");
  expect(fetch.mock.calls[0][1].credentials).toBe("include");
});

test("registration explicitly warns when Telegram bot is not configured", async () => {
  await registerAccount(false);
  expect(container.querySelector('[role="alert"]').textContent).toContain("البوت غير مهيّأ");
  expect(container.querySelector('[data-testid="register-telegram-link"]')).not.toBeNull();
});

test("gate does not label a freshly prepared link expired", async () => {
  fetch.mockResolvedValue(reply({ telegram_bot_configured: true }));
  mockAuthFetch.mockImplementation(async (path) => reply(path.endsWith("/status") ? { verified: false, challenge_active: false } : link()));
  await act(async () => root.render(<TelegramGate><div>Workspace</div></TelegramGate>));
  expect(container.querySelector('[data-testid="tg-bot-link"]').href).toBe(link().deep_link);
  expect(container.querySelector('[data-testid="tg-poll-status"]').textContent).not.toContain("expired");
  expect(mockAuthFetch.mock.calls.filter(([path]) => path.endsWith("/start"))).toHaveLength(1);
});

test("gate keeps the user informed instead of silently waiting for an unconfigured bot", async () => {
  fetch.mockResolvedValue(reply({ telegram_bot_configured: false }));
  mockAuthFetch.mockImplementation(async (path) => reply(path.endsWith("/status") ? { verified: false, challenge_active: false } : { ...link(), telegram_bot_configured: false }));
  await act(async () => root.render(<TelegramGate><div>Workspace</div></TelegramGate>));
  expect(container.querySelector('[role="alert"]').textContent).toContain("مفتاح بوت Telegram غير مهيّأ");
  expect(container.querySelector('[data-testid="tg-poll-status"]').textContent).toContain("بانتظار تهيئة");
});

test("challenge failure shows an inline error and not a generic fake private link", async () => {
  fetch.mockResolvedValue(reply({}));
  mockAuthFetch.mockImplementation(async (path) => path.endsWith("/status") ? reply({ verified: false }) : reply({ detail: "Cannot create link" }, false));
  await act(async () => root.render(<TelegramGate><div>Workspace</div></TelegramGate>));
  expect(container.querySelector('[role="alert"]').textContent).toContain("Cannot create link");
  expect(container.querySelector('[data-testid="tg-bot-link"]')).toBeNull();
  expect(container.querySelector('[data-testid="tg-new-challenge-btn"]').disabled).toBe(false);
});

test("standalone registration activates native account without contacting Telegram", async () => {
  mockRegister.mockResolvedValue({ token: "native-token", recovery_code: "SAVE-THIS", telegram_required: false });
  await act(async () => root.render(<Register />));
  await input("reg-username", "local_user"); await input("reg-password", "NativePassword1");
  await act(async () => container.querySelector("form").dispatchEvent(new Event("submit", { bubbles: true, cancelable: true })));
  expect(container.querySelector('[data-testid="recovery-code"]').textContent).toBe("SAVE-THIS");
  expect(container.querySelector('[data-testid="register-telegram-step"]')).toBeNull();
  expect(fetch).not.toHaveBeenCalled();
  await act(async () => container.querySelector('[data-testid="recovery-done"]').click());
  expect(mockActivate).toHaveBeenCalledWith("native-token");
});

test("standalone gate opens workspace without creating a Telegram challenge", async () => {
  fetch.mockResolvedValue(reply({ telegram_required: false, telegram_bot_configured: false }));
  mockAuthFetch.mockResolvedValue(reply({ verified: false }));
  await act(async () => root.render(<TelegramGate><div data-testid="native-workspace">Workspace</div></TelegramGate>));
  expect(container.querySelector('[data-testid="native-workspace"]')).not.toBeNull();
  expect(container.querySelector('[data-testid="telegram-gate"]')).toBeNull();
  expect(mockAuthFetch.mock.calls.filter(([path]) => path.endsWith("/start"))).toHaveLength(0);
});
