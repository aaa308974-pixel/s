import React, { lazy, Suspense, useEffect, useRef, useState } from "react";
import { Play } from "lucide-react";
import { LanguageSwitcher, useI18n } from "@/i18n";
import "@/i18n/catalogs/chat";
import Sidebar, { SidebarOpenButton } from "@/components/chat/Sidebar";
import ChatInput from "@/components/chat/ChatInput";
import ModelPicker, { DEFAULT_MODEL_ID } from "@/components/chat/ModelPicker";
import Message from "@/components/chat/Message";
import WelcomeState, { SuggestionPrompts } from "@/components/chat/WelcomeState";
import SettingsDialog from "@/components/chat/SettingsDialog";
import ThemeSwitcher from "@/components/design/ThemeSwitcher";
import { useChat } from "@/context/ChatContext";
import { useAuth } from "@/context/AuthContext";
import { streamStore } from "@/context/streamStore";
import { ActionButton, LoadingState, PageShell } from "@/components/design/Primitives";
import { BuilderProjectsProvider } from "@/builder/BuilderProjectsContext";
import "@/components/chat/chat-ui.css";
import "@/components/chat/chat-context-menu.css";

const BuilderWorkspace = lazy(() => import("@/builder/BuilderWorkspace"));

function useIsMobile() {
  const [mobile, setMobile] = useState(() => typeof window !== "undefined" && window.innerWidth < 768);
  useEffect(() => {
    const onResize = () => setMobile(window.innerWidth < 768);
    window.addEventListener("resize", onResize, { passive: true });
    return () => window.removeEventListener("resize", onResize);
  }, []);
  return mobile;
}

function useKeyboardOffset() {
  const [offset, setOffset] = useState(0);
  useEffect(() => {
    if (typeof window === "undefined" || !window.visualViewport) return undefined;
    const vv = window.visualViewport;
    const update = () => {
      const hidden = Math.max(0, window.innerHeight - vv.height - vv.offsetTop);
      setOffset(hidden > 60 ? hidden : 0);
    };
    update();
    vv.addEventListener("resize", update);
    vv.addEventListener("scroll", update);
    return () => { vv.removeEventListener("resize", update); vv.removeEventListener("scroll", update); };
  }, []);
  return offset;
}

export default function ChatLayout({ onOpenDashboard, onOpenAdmin, onStatus, builderMode = false }) {
  const {
    activeChat, isStreaming, paused, continueGeneration,
    phase: streamPhase, status: streamStatus, prefs = {}, setModel, aiModels,
  } = useChat();
  const phase = streamPhase || streamStatus?.phase || (isStreaming ? "streaming" : "idle");
  const { user, logout } = useAuth();
  const { t, dir } = useI18n("chat");
  const isMobile = useIsMobile();
  const keyboardOffset = useKeyboardOffset();
  const [sidebarOpen, setSidebarOpen] = useState(() => typeof window === "undefined" || window.innerWidth >= 768);
  const [builderVisited, setBuilderVisited] = useState(builderMode);
  useEffect(() => { if (builderMode) setBuilderVisited(true); }, [builderMode]);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [suggestion, setSuggestion] = useState(null);
  const [awayFromLatest, setAwayFromLatest] = useState(false);
  const scrollRef = useRef(null);
  const stickToBottom = useRef(true);
  const activeChatId = activeChat?.id;

  useEffect(() => {
    stickToBottom.current = true;
    setAwayFromLatest(false);
  }, [activeChatId]);
  useEffect(() => { setSidebarOpen(!isMobile); }, [isMobile]);
  useEffect(() => { onStatus?.(phase); }, [onStatus, phase]);
  useEffect(() => {
    if (!isMobile || !sidebarOpen) return undefined;
    const onKeyDown = (event) => {
      if (event.key === "Escape") setSidebarOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [isMobile, sidebarOpen]);

  useEffect(() => {
    let scrollFrame = null;
    let lastScrollAt = -Infinity;
    const unsubscribe = streamStore.subscribe(() => {
      if (scrollFrame != null || !stickToBottom.current || !scrollRef.current) return;
      scrollFrame = requestAnimationFrame((now) => {
        scrollFrame = null;
        const element = scrollRef.current;
        if (!element || !stickToBottom.current || now - lastScrollAt < 48) return;
        lastScrollAt = now;
        element.scrollTop = element.scrollHeight;
      });
    });
    return () => {
      unsubscribe();
      if (scrollFrame != null) cancelAnimationFrame(scrollFrame);
    };
  }, []);

  useEffect(() => {
    const element = scrollRef.current;
    if (!element || !stickToBottom.current) return;
    element.scrollTop = element.scrollHeight;
  }, [activeChatId, activeChat?.messages?.length, isStreaming]);

  const onScroll = () => {
    const element = scrollRef.current;
    if (!element) return;
    const distance = element.scrollHeight - element.scrollTop - element.clientHeight;
    const atBottom = distance < 120;
    stickToBottom.current = atBottom;
    setAwayFromLatest(!atBottom);
  };

  const scrollToLatest = () => {
    const element = scrollRef.current;
    if (!element) return;
    element.scrollTop = element.scrollHeight;
    stickToBottom.current = true;
    setAwayFromLatest(false);
  };

  const title = activeChat?.title || t("محادثة جديدة");
  const hasMessages = Boolean(activeChat && activeChat.messages.length > 0);
  const loadingHistory = Boolean(activeChat && (activeChat.messagesLoading || activeChat.messagesLoaded === false));
  const isWelcome = !hasMessages && !loadingHistory;

  return (
    <PageShell className="chat-app-shell">
      <BuilderProjectsProvider>
      <div className="chat-workspace">
        <div className={`chat-sidebar-slot ${isMobile ? "is-mobile" : ""}`}>
          {isMobile && sidebarOpen && <button type="button" className="chat-backdrop" onClick={() => setSidebarOpen(false)} data-testid="sidebar-backdrop" aria-label={t("إغلاق الشريط الجانبي")} />}
          <Sidebar
            open={sidebarOpen}
            onToggle={() => setSidebarOpen((value) => !value)}
            onOpenSettings={() => setSettingsOpen(true)}
            onOpenDashboard={onOpenDashboard}
            onOpenAdmin={onOpenAdmin}
            onLogout={logout}
            user={user}
            builderMode={builderMode}
          />
        </div>

        {builderVisited && <div className="builder-slot" hidden={!builderMode}><Suspense fallback={<div className="chat-main"><LoadingState label="جارٍ فتح Builder…" /></div>}><BuilderWorkspace active={builderMode} onOpenSidebar={() => setSidebarOpen(true)} sidebarOpen={sidebarOpen} onOpenSettings={() => setSettingsOpen(true)} /></Suspense></div>}
        <section hidden={builderMode} className={`chat-main ${isWelcome ? "is-empty" : "has-messages"}`} aria-label={t("مساحة المحادثة")} dir={dir} data-chat-state={loadingHistory ? "loading" : hasMessages ? "conversation" : "welcome"}>
          <header className="chat-topbar">
            <div className="chat-topbar-side chat-topbar-side-start">
              {!sidebarOpen && <SidebarOpenButton onClick={() => setSidebarOpen(true)} />}
              <ModelPicker className="chat-header-model" value={prefs.modelId || DEFAULT_MODEL_ID} onChange={setModel} models={aiModels} disabled={isStreaming} />
            </div>
            <div className="chat-topbar-side chat-topbar-side-end">
              <LanguageSwitcher className="chat-language-switcher" />
              <ThemeSwitcher />
              <div className="chat-header-status" data-state={phase === "idle" ? "ready" : phase} aria-live="polite">
                <span className={`chat-status-dot ${isStreaming ? "is-live" : ""}`} aria-hidden="true" />
                <span>{phase === "connecting" ? t("جارٍ الاتصال") : phase === "finalizing" ? t("جارٍ الحفظ") : phase === "streaming" ? t("جاري الرد") : ""}</span>
              </div>
            </div>
          </header>

          <div ref={scrollRef} onScroll={onScroll} className="chat-scroll scroll-elegant" data-testid="chat-scroll" role="log" aria-label={t("سجل المحادثة")} aria-busy={isStreaming} aria-relevant="additions text">
            {activeChat && (activeChat.messagesLoading || activeChat.messagesLoaded === false) ? (
              <div className="chat-document-loading"><LoadingState label={t("جارٍ تحميل المحادثة…")} /></div>
            ) : hasMessages ? (
              <div className="chat-document">
                {activeChat.messages.map((message) => (
                  <Message key={message.id} message={message} isStreamingThis={isStreaming && message.id === activeChat.messages[activeChat.messages.length - 1]?.id} />
                ))}
              </div>
            ) : null}
          </div>

          {awayFromLatest && <button className="chat-jump-to-latest" type="button" onClick={scrollToLatest} data-testid="jump-to-latest-btn" aria-label={t("العودة إلى آخر الرسائل")}>{t("العودة إلى آخر الرسائل")}</button>}

          <div className="chat-composer-dock" data-testid="chat-composer-stage" data-position={isWelcome ? "center" : "bottom"} style={!isWelcome ? { bottom: keyboardOffset } : undefined}>
            {isWelcome && <WelcomeState key="welcome" showSuggestions={false} />}
            {paused && <div className="chat-continue"><ActionButton tone="ghost" onClick={continueGeneration} data-testid="continue-generation-btn"><Play className="w-3.5 h-3.5" aria-hidden="true" />{t("متابعة التوليد")}</ActionButton></div>}
            <ChatInput key="composer" suggestion={suggestion} active={!builderMode} />
            {isWelcome && <SuggestionPrompts onSuggestedPrompt={setSuggestion} />}
          </div>
        </section>
      </div>
      </BuilderProjectsProvider>
      <SettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} />
    </PageShell>
  );
}
