import React, { lazy, memo, Suspense, useEffect, useRef, useState } from "react";
import { Check, ChevronDown, ChevronRight, Copy, Download, WrapText } from "lucide-react";
import StreamCodeBlock from "./StreamCodeBlock";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/chat";

const LazyHighlightedCode = lazy(() => import("./HighlightedCode"));
const LANG_ALIAS = { js: "javascript", jsx: "javascript", ts: "typescript", tsx: "typescript", py: "python", html: "markup", xml: "markup", sh: "bash", shell: "bash", yml: "yaml" };
const SUPPORTED = new Set(["javascript", "typescript", "python", "json", "markup", "css", "bash"]);

function DeferredHighlightedCode({ language, value, wrap }) {
  const container = useRef(null);
  const [ready, setReady] = useState(false);
  const canHighlight = value.length <= 14000 && value.split("\n").length <= 300;
  useEffect(() => {
    if (!canHighlight || typeof IntersectionObserver === "undefined") return undefined;
    let alive = true;
    let idle = null;
    const observe = new IntersectionObserver((entries) => {
      if (!entries.some((entry) => entry.isIntersecting) || idle != null) return;
      observe.disconnect();
      const enable = () => { if (alive) setReady(true); };
      idle = typeof requestIdleCallback === "function" ? requestIdleCallback(enable) : setTimeout(enable, 80);
    }, { rootMargin: "100px" });
    if (container.current) observe.observe(container.current);
    return () => {
      alive = false;
      observe.disconnect();
      if (idle != null) {
        if (typeof cancelIdleCallback === "function") cancelIdleCallback(idle);
        else clearTimeout(idle);
      }
    };
  }, [canHighlight]);
  return <div ref={container}>{ready && canHighlight
    ? <Suspense fallback={<StreamCodeBlock value={value} wrap={wrap} />}><LazyHighlightedCode language={language} value={value} wrap={wrap} /></Suspense>
    : <StreamCodeBlock value={value} wrap={wrap} />}</div>;
}

function CodeBlockImpl({ language, value = "", streaming = false }) {
  const { t } = useI18n("chat");
  const [copied, setCopied] = useState(false);
  const [wrap, setWrap] = useState(false);
  const [open, setOpen] = useState(true);
  const cleanValue = String(value).replace(/\n$/, "");
  const lang = (LANG_ALIAS[language] || language || "text").toLowerCase();
  const copy = async () => { try { await navigator.clipboard.writeText(cleanValue); setCopied(true); window.setTimeout(() => setCopied(false), 1500); } catch {} };
  const download = () => { const url = URL.createObjectURL(new Blob([cleanValue], { type: "text/plain" })); const anchor = document.createElement("a"); anchor.href = url; anchor.download = `snippet.${language || "txt"}`; anchor.click(); URL.revokeObjectURL(url); };
  return <div dir="ltr" data-testid="code-block" data-streaming={streaming ? "1" : "0"}>
    <div className="code-toolbar" dir="ltr">
      <div className="flex items-center gap-2"><button onClick={() => setOpen((current) => !current)} aria-label={t("طي أو فتح كتلة الكود")} data-testid="code-toggle-btn">{open ? <ChevronDown size={15} aria-hidden="true" /> : <ChevronRight size={15} aria-hidden="true" />}</button><span className="font-mono text-[11px] uppercase tracking-wider text-zinc-400">{lang}</span></div>
      <div className="flex items-center gap-1"><button onClick={() => setWrap((current) => !current)} className={wrap ? "text-[#E69BB0]" : ""} title={t("التفاف الأسطر")} aria-label={t("تبديل التفاف الأسطر")} data-testid="code-wrap-btn"><WrapText size={15} aria-hidden="true" /></button><button onClick={download} title={t("تنزيل الكود")} aria-label={t("تنزيل الشيفرة")} data-testid="code-download-btn"><Download size={15} aria-hidden="true" /></button><button onClick={copy} title={t("نسخ الشيفرة")} aria-label={t("نسخ الشيفرة")} data-testid="code-copy-btn">{copied ? <><Check size={15} className="text-emerald-300" aria-hidden="true" /><span className="hidden sm:inline text-[11px]">{t("تم النسخ")}</span></> : <><Copy size={15} aria-hidden="true" /><span className="hidden sm:inline text-[11px]">{t("نسخ الشيفرة")}</span></>}</button></div>
    </div>
    {open && <div className="code-block-scroll" dir="ltr">{streaming || !SUPPORTED.has(lang) ? <StreamCodeBlock value={cleanValue} wrap={wrap} /> : <DeferredHighlightedCode language={lang} value={cleanValue} wrap={wrap} />}</div>}
  </div>;
}
export default memo(CodeBlockImpl, (a, b) => a.value === b.value && a.language === b.language && a.streaming === b.streaming);
