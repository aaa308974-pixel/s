import React from "react";
import { Coins, TrendingUp } from "lucide-react";
import { useTokens } from "@/context/TokensContext";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/chat";
function formatLocalizedTokens(value, formatNumber) {
  if (value === -1 || value === null || value === undefined) return "∞";
  if (typeof value !== "number") return String(value);
  return formatNumber(value);
}

export function TokenBalanceChip() {
  const { t, formatNumber } = useI18n("chat");
  const { balance, isUnlimited, loading } = useTokens();
  if (loading) return <div className="h-11 w-full animate-pulse rounded-lg border border-[#30353F] bg-[#181C24]" data-testid="token-chip-loading" />;
  const value = isUnlimited ? -1 : (balance?.token_balance ?? 0);
  const empty = !isUnlimited && value <= 0;
  const low = !isUnlimited && value > 0 && value < 50000;
  return <div data-testid="token-balance-chip" className={`deepseek-token-balance flex min-h-[44px] w-full items-center gap-2 rounded-lg border px-3 ${empty ? "border-red-500/40 bg-red-500/10 text-red-200" : low ? "border-amber-500/40 bg-amber-500/10 text-amber-200" : "border-[#30353F] bg-[#181C24] text-zinc-300"}`}><Coins size={16} className={empty ? "text-red-300" : low ? "text-amber-300" : "text-[#E69BB0]"} aria-hidden="true" /><span className="min-w-0 flex-1"><small className="block text-[10px] uppercase tracking-[.12em] text-zinc-500">{t("الرصيد")}</small><strong className="block text-[13px] tabular-nums" dir="ltr" data-testid="token-balance-value">{formatLocalizedTokens(value, formatNumber)}</strong></span></div>;
}
export function MessageUsageStats({ usage }) {
  const { t, formatNumber } = useI18n("chat");
  if (!usage || typeof usage !== "object") return null;
  const { input, output, total, remaining } = usage;
  return <div data-testid="message-usage-stats" className="deepseek-message-usage mt-2 flex flex-wrap gap-x-4 gap-y-1 border-t border-[#30353F] pt-2 text-[11px] tabular-nums text-zinc-500" dir="ltr"><span className="inline-flex items-center gap-1"><TrendingUp size={12} className="text-[#E69BB0]" aria-hidden="true" /> {t("الإدخال")}: <b className="text-zinc-300">{formatLocalizedTokens(input, formatNumber)}</b></span><span>{t("الإخراج")}: <b className="text-zinc-300">{formatLocalizedTokens(output, formatNumber)}</b></span><span>{t("الإجمالي")}: <b className="text-zinc-300">{formatLocalizedTokens(total, formatNumber)}</b></span>{remaining !== undefined && remaining >= 0 && <span>{t("المتبقي")}: <b className="text-zinc-300">{formatLocalizedTokens(remaining, formatNumber)}</b></span>}</div>;
}
