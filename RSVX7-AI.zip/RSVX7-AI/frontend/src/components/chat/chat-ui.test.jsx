import React from "react";

jest.mock("remark-gfm", () => () => null);
jest.mock("react-markdown", () => ({ children }) => <div data-testid="mock-markdown">{children}</div>);
import { act } from "react";
import { createRoot } from "react-dom/client";
import Markdown from "./Markdown";
import CodeBlock from "./CodeBlock";
import HighlightedCode from "./HighlightedCode";
import ChatLayout from "./ChatLayout";
import ChatInput from "./ChatInput";
import Sidebar from "./Sidebar";
import WelcomeState from "./WelcomeState";

let container;
let root;
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});
afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
});

test("streaming Markdown renders a plain code block without mounting a highlighter", async () => {
  await act(async () => root.render(<Markdown streaming>{"```js\nconst answer = 42;\n```"}</Markdown>));
  const block = container.querySelector('[data-testid="code-block"]');
  expect(block).not.toBeNull();
  expect(block.getAttribute("data-streaming")).toBe("1");
  expect(container.textContent).toContain("const answer = 42;");
});

test("code block actions and chat module exports remain available", async () => {
  await act(async () => root.render(<CodeBlock language="text" value="hello" streaming />));
  expect(container.querySelector('[data-testid="code-copy-btn"]')).not.toBeNull();
  expect(typeof ChatLayout).toBe("function");
  expect(typeof ChatInput).toBe("function");
  expect(typeof Sidebar).toBe("function");
  expect(typeof HighlightedCode).toBe("function");
});

test("welcome state keeps the DeepSeek-style greeting free of suggestion cards", async () => {
  await act(async () => root.render(<WelcomeState />));
  expect(container.querySelector('[data-testid="welcome-state"]')).not.toBeNull();
  expect(container.querySelector('[data-testid="welcome-greeting"]')).not.toBeNull();
  expect(container.querySelectorAll('[data-testid^="suggestion-"]')).toHaveLength(0);
  expect(container.textContent).toContain("مرحبًا، أنا rsvx7");
});
