import React from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/context/AuthContext";
import { useTokens } from "@/context/TokensContext";
import { useChat } from "@/context/ChatContext";
import { Brain, Database, Gauge, Settings2, ShieldCheck, Ticket, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { LanguageSwitcher, useI18n } from "@/i18n";
import "@/i18n/catalogs/account";
import "@/pages/dashboard-ui.css";

export default function SettingsDialog({ open, onOpenChange }) {
  const { t, dir, formatNumber } = useI18n("account");
  const {
    prefs = {},
    setPrefs,
    chats = [],
    deleteChat,
    reasoningSupported,
    reasoningMandatory,
    aiModel,
    webSearchSupported,
    setDeepThink,
    setWebSearch,
  } = useChat();
  const { authFetch, refresh } = useAuth();
  const { refresh: refreshBalance } = useTokens();
  const [couponCode, setCouponCode] = React.useState("");
  const [redeeming, setRedeeming] = React.useState(false);
  const [clearing, setClearing] = React.useState(false);
  const [activeSection, setActiveSection] = React.useState("workspace");
  const redemptionRef = React.useRef(null);
  const redeemingRef = React.useRef(false);
  const reasoningKnown = typeof reasoningSupported === "boolean";
  const canDeepThink = reasoningSupported === true;
  const searchKnown = typeof webSearchSupported === "boolean";
  const canSearch = webSearchSupported === true;

  const navigateTo = (section) => {
    setActiveSection(section);
    document.getElementById(`settings-section-${section}`)?.scrollIntoView?.({ block: "nearest" });
  };

  const redeem = async () => {
    const code = couponCode.trim();
    if (!code || redeemingRef.current) return;
    redeemingRef.current = true;
    setRedeeming(true);
    if (!redemptionRef.current || redemptionRef.current.code !== code) {
      redemptionRef.current = {
        code,
        id: globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      };
    }
    try {
      const response = await authFetch("/coupons/redeem", {
        method: "POST",
        body: JSON.stringify({ code, idempotency_key: redemptionRef.current.id }),
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(typeof result.detail === "string" ? result.detail : result.detail?.message || t("تعذر استخدام الكوبون"));
      }
      toast.success(t("تم استبدال القسيمة! +{tokens} توكن", { tokens: formatNumber(result.tokens || 0) }));
      setCouponCode("");
      redemptionRef.current = null;
      await Promise.all([refresh?.(), refreshBalance?.()]);
    } catch (error) {
      toast.error(error?.message || t("حدث خطأ في الشبكة. حاول مرة أخرى."));
    } finally {
      redeemingRef.current = false;
      setRedeeming(false);
    }
  };

  const clearAll = async () => {
    if (clearing || !window.confirm(t("حذف جميع محادثات المشروع الحالي؟ لا يمكن التراجع عن ذلك."))) return;
    setClearing(true);
    try {
      for (const chat of chats) {
        if (!(await deleteChat(chat.id))) throw new Error(t("تعذر حذف بعض المحادثات. أعد المحاولة لإزالة بقية المحادثات."));
      }
      toast.success(t("تم حذف محادثات هذا المشروع."));
    } catch (error) {
      toast.error(error?.message || t("تعذر حذف المحادثات"));
    } finally {
      setClearing(false);
    }
  };

  const modelLabel = aiModel || t("يحدده المسؤول");
  const reasoningLabel = reasoningKnown
    ? (canDeepThink ? t("DeepThink متاح لهذا النموذج") : t("DeepThink غير متاح لهذا النموذج"))
    : t("لم يعلن الخادم دعم DeepThink بعد");
  const searchLabel = searchKnown
    ? (canSearch ? t("البحث متاح") : t("البحث غير مهيأ"))
    : t("البحث غير مهيأ");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="mr7-settings-dialog" data-testid="settings-dialog">
        <DialogHeader className="mr7-settings-header">
          <div>
            <DialogTitle><Settings2 size={18} className="mr7-settings-header-icon" aria-hidden="true" /> {t("الإعدادات")}</DialogTitle>
            <DialogDescription>{t("إعدادات مساحة rsvx7، بدون تغيير البيانات أو الصلاحيات.")}</DialogDescription>
          </div>
        </DialogHeader>
        <div className="mr7-settings-body" dir={dir} data-testid="settings-body">
          <nav className="mr7-settings-nav deepseek-settings-nav" aria-label={t("أقسام الإعدادات")}>
            <p className="mr7-settings-nav-label">{t("الإعدادات")}</p>
            <button type="button" className={`mr7-settings-nav-item ${activeSection === "workspace" ? "is-active" : ""}`} aria-current={activeSection === "workspace" ? "page" : undefined} onClick={() => navigateTo("workspace")}>{t("مساحة العمل")}</button>
            <button type="button" className={`mr7-settings-nav-item ${activeSection === "billing" ? "is-active" : ""}`} aria-current={activeSection === "billing" ? "page" : undefined} onClick={() => navigateTo("billing")}>{t("الرصيد")}</button>
            <button type="button" className={`mr7-settings-nav-item ${activeSection === "data" ? "is-active" : ""}`} aria-current={activeSection === "data" ? "page" : undefined} onClick={() => navigateTo("data")}>{t("البيانات")}</button>
          </nav>

          <div className="mr7-settings-sections">
            <section className="mr7-settings-section" id="settings-section-workspace" aria-labelledby="settings-workspace-title">
              <div className="mr7-settings-section-heading">
                <Brain size={17} aria-hidden="true" />
                <div>
                  <h3 id="settings-workspace-title">{t("المساحة والنموذج")}</h3>
                  <p>{t("الشخصية تُختار من المحرر، والنموذج يحدده الخادم وفق الصلاحية الحالية.")}</p>
                </div>
              </div>
              <div className="mr7-settings-stack">
                <div className="mr7-settings-row" data-testid="model-status">
                  <div className="mr7-settings-row-copy"><strong>{t("النموذج الحالي")}</strong><span dir="ltr">{modelLabel}</span></div>
                  <span className="mr7-settings-help">{reasoningLabel}</span>
                </div>
                <div className="mr7-settings-row" data-testid="language-field">
                  <div className="mr7-settings-row-copy"><strong>{t("اللغة")}</strong><span>{t("اختر لغة واجهة الحساب.")}</span></div>
                  <LanguageSwitcher className="mr7-settings-language-switcher" />
                </div>
                {canDeepThink && (
                  <div className="mr7-settings-row">
                    <div className="mr7-settings-row-copy"><strong>DeepThink</strong><span>{t("يظهر فقط عندما يعلن النموذج دعمه الحقيقي.")}</span></div>
                    <Switch checked={Boolean(reasoningMandatory || prefs.deepThink)} disabled={!setDeepThink || reasoningMandatory} onCheckedChange={(enabled) => setDeepThink?.(reasoningMandatory ? true : enabled)} data-testid="deepthink-switch" />
                  </div>
                )}
                <div className="mr7-settings-row">
                  <div className="mr7-settings-row-copy"><strong>{t("البحث")}</strong><span>{searchLabel}. {t("لا نعرض زرًا غير مهيأ.")}</span></div>
                  {canSearch && <Switch checked={Boolean(prefs.webSearch)} disabled={!setWebSearch} onCheckedChange={(enabled) => setWebSearch?.(enabled)} data-testid="websearch-switch" />}
                </div>
                <div className="mr7-settings-row">
                  <div className="mr7-settings-row-copy"><strong>{t("نص يُضاف إلى كل رسالة")}</strong><span>{t("يمكنك تعديله أو إيقافه في أي وقت.")}</span></div>
                  <Switch checked={!!prefs.autoSuffix?.enabled} onCheckedChange={(enabled) => setPrefs((current) => ({ ...current, autoSuffix: { ...(current.autoSuffix || {}), enabled } }))} data-testid="auto-suffix-switch" />
                </div>
                <Textarea value={prefs.autoSuffix?.text || ""} maxLength={5000} onChange={(event) => setPrefs((current) => ({ ...current, autoSuffix: { ...(current.autoSuffix || {}), text: event.target.value } }))} className="mr7-settings-textarea" aria-label={t("النص المضاف إلى الرسائل")} data-testid="auto-suffix-text" />
              </div>
            </section>

            <section className="mr7-settings-section" id="settings-section-billing" aria-labelledby="settings-billing-title">
              <div className="mr7-settings-section-heading">
                <Ticket size={17} aria-hidden="true" />
                <div>
                  <h3 id="settings-billing-title">{t("استبدال قسيمة")}</h3>
                  <p>{t("أدخل رمزًا شاركه المسؤول لإضافة الرصيد. إعادة المحاولة تستخدم المفتاح نفسه.")}</p>
                </div>
              </div>
              <div className="mr7-settings-coupon">
                <div>
                  <Label className="mr7-settings-field-label" htmlFor="redeem-input">{t("رمز القسيمة")}</Label>
                  <Input value={couponCode} disabled={redeeming} maxLength={32} onChange={(event) => { setCouponCode(event.target.value.toUpperCase()); redemptionRef.current = null; }} placeholder="WELCOME10" data-testid="redeem-input" className="mr7-settings-input font-mono uppercase" onKeyDown={(event) => { if (event.key === "Enter") { event.preventDefault(); void redeem(); } }} />
                </div>
                <Button onClick={redeem} disabled={redeeming || !couponCode.trim()} data-testid="redeem-btn" className="mr7-settings-button">{redeeming ? "…" : t("استبدال")}</Button>
              </div>
            </section>

            <section className="mr7-settings-section" id="settings-section-data" aria-labelledby="settings-data-title">
              <div className="mr7-settings-section-heading">
                <Database size={17} aria-hidden="true" />
                <div>
                  <h3 id="settings-data-title">{t("البيانات")}</h3>
                  <p>{t("{count} محادثات في هذا المشروع. الحذف نهائي ولا يغيّر بقية المشاريع.", { count: formatNumber(chats.length) })}</p>
                </div>
              </div>
              <div className="mr7-settings-row">
                <div className="mr7-settings-row-copy"><strong>{t("حذف محادثات المشروع")}</strong><span>{t("إذا فشل حذف محادثة، يمكنك إعادة المحاولة دون إعلان نجاح وهمي.")}</span></div>
                <Button variant="destructive" onClick={clearAll} disabled={clearing || !chats.length} data-testid="clear-all-btn" className="mr7-settings-button mr7-settings-button-danger"><Trash2 size={15} aria-hidden="true" />{clearing ? "…" : t("مسح الكل")}</Button>
              </div>
              <div className="mr7-settings-status"><ShieldCheck size={15} aria-hidden="true" /> {t("الجلسة والصلاحيات محفوظة عبر AuthContext ولا تُعرض هنا.")}</div>
            </section>
            <div className="mr7-settings-footer"><Gauge size={12} aria-hidden="true" /> {t("إعدادات قابلة للتراجع · {year}", { year: formatNumber(new Date().getFullYear()) })}</div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
