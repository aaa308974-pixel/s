import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Code2, Eye, MessageSquare, Download, Save, FolderCode, ArrowLeft, Menu, Settings2, LoaderCircle, Play, X } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useChat } from '@/context/ChatContext';
import { useBuilderProjects } from './BuilderProjectsContext';
import { useTokens } from '@/context/TokensContext';
import { LanguageSwitcher, useI18n } from '@/i18n';
import { registerTranslations } from '@/i18n/runtime';
import ThemeSwitcher from '@/components/design/ThemeSwitcher';
import ChatInput from '@/components/chat/ChatInput';
import Markdown from '@/components/chat/Markdown';
import { createRuntime } from './runtime';
import { formatChatError } from './generated-runtime';
import { createRequestId } from './requestId';
import PreviewFrame from './PreviewFrame';
import { BuildProgress } from './generated-widgets';
import CodeEditor from './CodeEditor';
import QuestionForm from './QuestionForm';
import ModelPicker, { DEFAULT_MODEL_ID } from '@/components/chat/ModelPicker';
import './builder.css';

registerTranslations('builder', { 'المحادثة': 'Chat', 'الكود': 'Code', 'المعاينة': 'Preview', 'تنزيل المشروع': 'Download project', 'حفظ': 'Save', 'إنشاء مشروعك': 'Build your project', 'صف الفكرة، ثم راجع التصور قبل التنفيذ.': 'Describe your idea, then review the proposal before building.', 'اعتماد وبدء التنفيذ': 'Approve and build', 'مراجعة التصور': 'Review proposal', 'إعادة الفحص': 'Run checks', 'تعديلات غير محفوظة': 'Unsaved changes', 'اختر ملفًا': 'Select a file', 'لا توجد ملفات بعد': 'No files yet', 'العودة إلى الدردشة': 'Back to chat', 'تعديل التصور': 'Revise proposal', 'جارٍ فتح المشروع…': 'Opening project…', 'إعادة المحاولة': 'Retry', 'مناقشة تعديل': 'Discuss changes', 'فتح القائمة': 'Open menu', 'الإعدادات': 'Settings', 'إغلاق': 'Close', 'ملفات المشروع': 'Project files', 'جارٍ العمل على المشروع': 'Working on the project', 'جارٍ تجهيز المعاينة': 'Preparing preview', 'فشلت بعض الفحوص. راجع النتائج أو اطلب من Builder إصلاح المشروع.': 'Some checks failed. Review the results or ask Builder to fix the project.' });
const empty = { revision: 0, files: {}, messages: [], checks: [], darkMode: true, phase: 'planning' };

export default function BuilderWorkspace({ onOpenSidebar, onOpenSettings, sidebarOpen = false, active = true }) {
  const { user, authFetch } = useAuth();
  const chat = useChat();
  const builderProjects = useBuilderProjects();
  const { refresh: refreshBalance } = useTokens();
  const { t, dir } = useI18n('builder');
  const tRef = useRef(t); tRef.current = t;
  const pid = builderProjects.activeId;
  const { loading: projectsLoading, projects: builderList, select: selectProject, create: createProject, refresh: refreshProjects } = builderProjects;
  const creatingRef = useRef(false);
  useEffect(() => {
    if (!active || projectsLoading || pid || creatingRef.current) return;
    if (builderList.length) { selectProject(builderList[0]._id); return; }
    creatingRef.current = true;
    createProject().catch((e) => setError(e.message)).finally(() => { creatingRef.current = false; });
  }, [active, projectsLoading, pid, builderList, selectProject, createProject]);
  const [data, setData] = useState(empty), dataRef = useRef(empty);
  const [loading, setLoading] = useState(true), [submitting, setSubmitting] = useState(false), [error, setError] = useState('');
  const [tab, setTab] = useState('chat'), [selected, setSelected] = useState(''), [dirty, setDirty] = useState(false);
  const [build, setBuild] = useState({ phase: 'idle', checks: [], files: 0, attempt: 0 });
  const [darkMode, setDarkMode] = useState(true);
  const dirtyRef = useRef(false), inFlight = useRef(false), messagesRef = useRef(null), stickToLatest = useRef(true);
  const loadSequence = useRef(0), pendingRequest = useRef(null);
  const handledCompletion = useRef('');
  const controller = useRef(null), runRef = useRef(null), applied = useRef(-1), repairNext = useRef(false), handledError = useRef(''), scope = useRef(0);
  const request = useCallback(async (path, options) => {
    const response = await authFetch('/builder/projects/' + encodeURIComponent(pid) + path, options);
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(typeof result.detail === 'string' ? result.detail : result.detail?.message || 'تعذّر إكمال الطلب.');
    return result;
  }, [authFetch, pid]);
  const load = useCallback(async () => {
    const epoch = scope.current;
    const sequence = ++loadSequence.current;
    const result = await request('?filesRevision=' + dataRef.current.revision);
    if (epoch !== scope.current || sequence !== loadSequence.current) return;
    if (dirtyRef.current && result.revision !== dataRef.current.revision) throw new Error('تغيّر المشروع في نافذة أخرى. نزّل تعديلاتك قبل إعادة التحميل.');
    const next = { ...dataRef.current, ...result };
    dataRef.current = next; setData(next); setLoading(false);
    return next;
  }, [request]);
  useEffect(() => {
    if (!pid) return;
    const epoch = ++scope.current;
    stickToLatest.current = true;
    inFlight.current = false; pendingRequest.current = null; repairNext.current = false; setSubmitting(false); setBuild({ phase: 'idle', checks: [], files: 0, attempt: 0 });
    setLoading(true); setError(''); setDirty(false); dirtyRef.current = false; setSelected(''); applied.current = -1; handledError.current = ''; handledCompletion.current = '';
    dataRef.current = { ...empty, revision: -1 }; setData(empty);
    const session = createRuntime(state => {
      if (scope.current !== epoch) return;
      setBuild(state);
      if (['ready', 'failed'].includes(state.phase) && state.checks?.length === 7 && state.checks.some(c => c.status === 'passed' || c.status === 'failed')) {
        void request('/checks', { method: 'POST', body: JSON.stringify({ revision: dataRef.current.revision, checks: state.checks }) }).catch(() => {});
      }
    }, repair => {
      if (!dataRef.current.approvedPlan) { session.runtime.pause(tRef.current('فشلت بعض الفحوص. راجع النتائج أو اطلب من Builder إصلاح المشروع.')); return; }
      repairNext.current = true; void runRef.current?.('repair', repair.prompt);
    });
    controller.current = session;
    let disposed = false, timer, initializedDark = false;
    const poll = async () => {
      try {
        const next = inFlight.current ? null : await load();
        if (next && scope.current === epoch) {
          if (!initializedDark) { initializedDark = true; setDarkMode(next.darkMode !== false); }
          if (next.job?.status === 'running' && next.job.mode === 'build' && ['idle', 'stopped'].includes(session.runtime.state.get().phase)) session.runtime.beginTask(true, next.job.request?.action === 'repair');
          if (next.job?.agents?.length) session.runtime.setAgentTasks(next.job.agents);
          if (next.job?.status === 'failed' && handledError.current !== next.job.id) {
            const message = next.job.error?.startsWith('DF_CHAT_ERROR:') ? formatChatError(next.job.error) : next.job.error;
            handledError.current = next.job.id; setError(message); void refreshProjects().catch(() => {});
            if (next.job.mode === 'build') session.runtime.pause(message);
          }
          if (next.job?.status === 'completed' && handledCompletion.current !== next.job.id) {
            handledCompletion.current = next.job.id; setError(''); void refreshProjects().catch(() => {});
          }
          if (next.job?.status !== 'running' && next.revision !== applied.current && Object.keys(next.files || {}).length) {
            applied.current = next.revision;
            setSelected(previous => next.files[previous] ? previous : Object.keys(next.files)[0]);
            void session.apply(next.files, repairNext.current); repairNext.current = false;
          }
        }
      } catch (e) { if (!disposed) { setError(e.message); setLoading(false); } }
      if (!disposed) timer = setTimeout(poll, dataRef.current.job?.status === 'running' ? 1500 : 6000);
    };
    poll();
    return () => { disposed = true; scope.current = epoch + 1; clearTimeout(timer); session.dispose(); controller.current = null; };
  }, [pid, user?._id, request, load, refreshProjects]);
  useEffect(() => {
    const element = messagesRef.current;
    if (element && stickToLatest.current) element.scrollTop = element.scrollHeight;
  }, [data.messages.length, pid]);
  const busy = submitting || data.job?.status === 'running';
  async function save() {
    const epoch = scope.current;
    if (!dirty) return dataRef.current.revision;
    const result = await request('/files', { method: 'PUT', body: JSON.stringify({ revision: dataRef.current.revision, files: dataRef.current.files }) });
    if (epoch !== scope.current) throw new Error('تغيّر المشروع المفتوح.');
    const next = { ...dataRef.current, revision: result.revision }; dataRef.current = next; setData(next); setDirty(false); dirtyRef.current = false; applied.current = result.revision;
    return result.revision;
  }
  async function run(action, text = '', proposalId, extra = {}) {
    if (!pid || busy || inFlight.current) return false;
    const epoch = scope.current;
    inFlight.current = true;
    ++loadSequence.current;
    setSubmitting(true); setError('');
    try {
      const revision = await save();
      if (epoch !== scope.current) return false;
      const payload = { revision, action, text, proposalId, darkMode, ...extra,
        personality: chat.prefs?.modelId || 'rsvx7-ai', deepThink: !!chat.prefs?.deepThink,
        autoSuffix: chat.prefs?.autoSuffix?.enabled ? chat.prefs.autoSuffix.text || '' : '' };
      const signature = JSON.stringify(payload);
      if (pendingRequest.current?.signature !== signature) pendingRequest.current = { signature, id: createRequestId() };
      const result = await request('/run', { method: 'POST', body: JSON.stringify({ ...payload, requestId: pendingRequest.current.id }) });
      if (epoch !== scope.current) return false;
      pendingRequest.current = null;
      ++loadSequence.current;
      dataRef.current = { ...dataRef.current, job: result.job }; setData(dataRef.current);
      if (result.job?.mode === 'build') {
        const repairing = result.job.request?.action === 'repair' || action === 'repair';
        repairNext.current = repairing;
        controller.current?.runtime.beginTask(true, repairing);
      }
      // An accepted job survives a refresh error. Never ask the composer/form
      // to resend a request that the server has already accepted.
      try { await load(); } catch (e) { if (epoch === scope.current) setError(e.message); }
      void refreshProjects().catch(() => {});
      return true;
    } catch (e) { if (epoch === scope.current) { setError(e.message); if (action === 'repair') controller.current?.runtime.pause(e.message); } return false; }
    finally { if (epoch === scope.current) { inFlight.current = false; setSubmitting(false); void refreshBalance(); } }
  }
  runRef.current = run;
  useEffect(() => { if (data.job?.status && data.job.status !== 'running') void refreshBalance(); }, [data.job?.status, refreshBalance]);
  async function stop() {
    controller.current?.stop();
    try { await request('/cancel', { method: 'POST', body: '{}' }); await load(); } catch (e) { setError(e.message); }
  }
  const verify = async () => {
    try { await save(); await controller.current?.apply(dataRef.current.files); } catch (e) { setError(e.message); }
  };
  async function download() {
    try {
      const { default: JSZip } = await import('jszip'); const zip = new JSZip();
      for (const [path, file] of Object.entries(dataRef.current.files)) zip.file(path.replace('/home/project/', ''), file.content, { base64: file.isBinary });
      const url = URL.createObjectURL(await zip.generateAsync({ type: 'blob' })); const anchor = document.createElement('a'); anchor.href = url; anchor.download = 'rsvx7-project.zip'; anchor.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (e) { setError(e.message); }
  }
  const composer = { sendMessage: (text, files) => run('message', files.length ? files.filter(f => f.status === 'ready').map(f => `Reference file ${f.name}:\n${f.text}`).join('\n\n') + '\n\n' + text : text),
    isStreaming: busy, messagesLoading: loading, saveErrors: [], stop, webSearchSupported: false,
    activeChat: { darkMode, messagesLoaded: !loading }, activateDarkMode: () => setDarkMode(true), deactivateDarkMode: () => setDarkMode(false) };
  const entries = Object.entries(data.files || {});
  const current = data.files?.[selected];
  return <section className="chat-main builder-workspace" dir={dir} data-testid="builder-workspace">
    <PreviewFrame state={build} runtime={controller.current?.runtime} verification />
    <header className="chat-topbar builder-topbar">
      <div className="chat-topbar-side">{!sidebarOpen && <button className="chat-icon-button" onClick={onOpenSidebar} aria-label={t('فتح القائمة')} data-testid="builder-open-sidebar-btn"><Menu size={18} /></button>}<span className="builder-badge"><Code2 size={16} />Builder</span><span className="builder-project-name" dir="auto" data-testid="builder-project-name">{builderList.find((p) => p._id === pid)?.name || data.projectName}</span></div>
      <div className="chat-topbar-side"><button className="chat-icon-button" onClick={onOpenSettings} aria-label={t('الإعدادات')} data-testid="builder-settings-btn"><Settings2 size={17} /></button><LanguageSwitcher /><ThemeSwitcher /></div>
    </header>
    <div className="builder-toolbar"><div className="builder-tabs" role="tablist" aria-label="Builder">
      {[['chat', 'المحادثة', MessageSquare], ['code', 'الكود', Code2], ['preview', 'المعاينة', Eye]].map(([id, label, Icon]) => <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)} data-testid={`builder-tab-${id}`}><Icon size={16} /><span>{t(label)}</span></button>)}
    </div><div className="builder-toolbar-actions">{data.approvedPlan && <button disabled={busy} title={t('مناقشة تعديل')} aria-label={t('مناقشة تعديل')} onClick={() => run('discuss', 'أريد مناقشة تعديل على المشروع الحالي. اسألني عن التعديل قبل تغيير الملفات.')} data-testid="builder-discuss-btn"><MessageSquare size={17} /></button>}<button onClick={download} data-testid="builder-download-btn" disabled={!entries.length} title={t('تنزيل المشروع')} aria-label={t('تنزيل المشروع')}><Download size={17} /></button><button onClick={verify} data-testid="builder-run-checks-btn" disabled={busy || !entries.length} title={t('إعادة الفحص')} aria-label={t('إعادة الفحص')}><Play size={16} /></button><button data-testid="builder-back-btn" onClick={() => { window.location.hash = '#chat'; }} title={t('العودة إلى الدردشة')} aria-label={t('العودة إلى الدردشة')}><ArrowLeft size={17} /></button></div></div>
    {error && <div className="builder-error" role="alert" data-testid="builder-error"><span>{error}</span>{['failed', 'cancelled'].includes(data.job?.status) && !busy && <button className="builder-retry" data-testid="builder-retry-btn" onClick={() => run('retry')}>{t('إعادة المحاولة')}</button>}<button aria-label={t('إغلاق')} data-testid="builder-error-close-btn" onClick={() => setError('')}><X size={16} /></button></div>}
    {loading || !pid ? <div className="builder-loading"><LoaderCircle className="animate-spin" size={20} />{t('جارٍ فتح المشروع…')}</div> : <>
      <div className="builder-body" data-view={tab}>
        <div className="builder-chat-pane">
          <div className="builder-messages" role="log" ref={messagesRef} onScroll={event => { const el = event.currentTarget; stickToLatest.current = el.scrollHeight - el.scrollTop - el.clientHeight < 120; }}>
            {!data.messages.length && <div className="builder-welcome"><FolderCode size={38} /><h1>{t('إنشاء مشروعك')}</h1><p>{t('صف الفكرة، ثم راجع التصور قبل التنفيذ.')}</p></div>}
            {data.messages.map(message => <article key={message.id} className={'builder-message ' + message.role}>
              {message.content && <Markdown>{message.content}</Markdown>}
              {message.plan?.kind === 'questions' && <QuestionForm key={[user?._id, pid, message.id].join(':')} questions={message.plan.questions}
                draftKey={[user?._id, pid, message.id].join(':')}
                initialAnswers={[...data.messages].reverse().find(m => m.questionMessageId === message.id)?.questionAnswers}
                disabled={busy || message.id !== data.proposalId || data.plan?.kind !== 'questions'}
                onSubmit={answers => run('answers', '', undefined, { questionMessageId: message.id, answers })} />}
              {message.plan?.kind === 'proposal' && <div className="builder-plan"><h2>{message.plan.title}</h2><p>{message.plan.summary}</p><div className="builder-plan-pages">{message.plan.pages.map(p => <div key={p.name}><strong>{p.name}</strong><small>{p.purpose}</small></div>)}</div><ul>{message.plan.features.map(f => <li key={f}>{f}</li>)}</ul><p>{message.plan.design}</p>{message.id === data.proposalId && !data.approvedPlan && <button className="builder-primary" data-testid="builder-approve-btn" disabled={busy} onClick={() => run('approve', '', message.id)}>{t('اعتماد وبدء التنفيذ')}</button>}</div>}
            </article>)}
            {data.job?.status === 'running' && data.job.mode === 'planning' && <div className="builder-planning" role="status"><LoaderCircle size={16} className="animate-spin" />{t('مراجعة التصور')}</div>}
          </div>
          {build.phase !== 'idle' && <BuildProgress state={build} onStop={stop} onRetry={() => ['failed', 'cancelled'].includes(data.job?.status) ? run('retry') : controller.current?.runtime.canRetryRepair ? controller.current.runtime.requestRepair() : controller.current?.runtime.canRetryPreview ? controller.current.runtime.retryPreview() : verify()} onRepair={() => controller.current?.runtime.requestRepair()} onPreview={() => setTab('preview')} />}
          <div className="builder-composer" data-testid="builder-composer"><div className="builder-composer-meta"><ModelPicker value={chat.prefs?.modelId || DEFAULT_MODEL_ID} onChange={chat.setModel} models={chat.aiModels || data.models} disabled={busy} /><span className="builder-model" dir="ltr" data-testid="builder-model-label">{busy && data.job?.model ? data.job.model : chat.aiModel || data.models?.[chat.prefs?.modelId]?.model || data.model}</span></div><ChatInput controller={composer} active={active} /></div>
        </div>
        <div className="builder-code-pane" hidden={tab !== 'code'}>
          <nav className="builder-files" aria-label={t('ملفات المشروع')} data-testid="builder-file-list">{entries.length ? entries.map(([path]) => <button key={path} className={selected === path ? 'active' : ''} onClick={() => setSelected(path)} dir="ltr" data-testid={`builder-file-${path.replace('/home/project/', '').replace(/[^a-zA-Z0-9]+/g, '-')}`}><Code2 size={13} />{path.replace('/home/project/', '')}</button>) : <span>{t('لا توجد ملفات بعد')}</span>}</nav>
          <div className="builder-editor-pane"><div className="builder-editor-toolbar"><span dir="ltr">{selected.replace('/home/project/', '')}</span><button data-testid="builder-save-btn" disabled={!dirty || busy} onClick={() => save().catch(e => setError(e.message))}><Save size={15} />{t('حفظ')}</button></div>{dirty && <div className="builder-unsaved">{t('تعديلات غير محفوظة')}</div>}{current && !current.isBinary ? <CodeEditor path={selected} value={current.content} disabled={busy} onChange={value => { const next = { ...dataRef.current, files: { ...dataRef.current.files, [selected]: { ...dataRef.current.files[selected], content: value } } }; dataRef.current = next; setData(next); setDirty(true); dirtyRef.current = true; controller.current?.runtime.invalidateChecks(); }} /> : <div className="builder-placeholder">{t('اختر ملفًا')}</div>}</div>
        </div>
        <div className="builder-preview-pane" hidden={tab !== 'preview'}>{build.previewUrl ? <PreviewFrame state={build} runtime={controller.current?.runtime} title={t('المعاينة')} /> : <div className="builder-placeholder"><Eye size={32} /><p>{t('المعاينة')}</p>{entries.length > 0 && <button className="builder-primary" data-testid="builder-preview-run-btn" disabled={busy} onClick={verify}>{t('إعادة الفحص')}</button>}</div>}{build.phase !== 'idle' && build.phase !== 'ready' && <div className="builder-preview-status">{build.message || t(busy ? 'جارٍ العمل على المشروع' : 'جارٍ تجهيز المعاينة')}</div>}</div>
      </div>
    </>}
  </section>;
}
