import React, { act } from "react";
import { createRoot } from "react-dom/client";
import Login from "./Login";
import ForcePasswordChange from "@/components/ForcePasswordChange";
import { getLanguage, setLanguage } from "@/i18n";
import "@/i18n/catalogs/auth";

const mockLogin = jest.fn();
const mockChangePassword = jest.fn();
const mockLogout = jest.fn();

jest.mock("@/context/AuthContext", () => ({
  useAuth: () => ({
    login: mockLogin,
    changePassword: mockChangePassword,
    logout: mockLogout,
    user: { username: "alice" },
  }),
}));
jest.mock("@/components/design/Primitives", () => ({
  AuthShell: ({ title, subtitle, className, children, footer }) => <main className={className}><h1>{title}</h1><p>{subtitle}</p>{children}{footer}</main>,
  Panel: ({ children, ...props }) => <section {...props}>{children}</section>,
  ActionButton: ({ children, loading, ...props }) => <button {...props} disabled={props.disabled || loading}>{children}</button>,
  StatusNote: ({ children }) => <div role="alert">{children}</div>,
}));

let container;
let root;

beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  setLanguage("en");
  mockLogin.mockReset();
  mockChangePassword.mockReset();
  mockLogout.mockReset();
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});

afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
  setLanguage("ar");
  localStorage.removeItem("rsvx7_language");
});

async function setInput(testId, value) {
  await act(async () => {
    const input = container.querySelector(`[data-testid="${testId}"]`);
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
  });
}

test("auth UI renders English copy, persists the choice, and keeps sign-in behavior", async () => {
  mockLogin.mockResolvedValueOnce({});
  await act(async () => root.render(<Login />));

  expect(getLanguage()).toBe("en");
  expect(localStorage.getItem("rsvx7_language")).toBe("en");
  expect(container.querySelector("h1").textContent).toBe("Welcome back");
  expect(container.querySelector('[data-testid="login-username"]').placeholder).toBe("Username");
  expect(container.querySelector("section[dir=\"ltr\"]")).not.toBeNull();
  expect(container.querySelector('[data-testid="login-submit"]').textContent).toContain("Sign in");

  await setInput("login-username", "alice");
  await setInput("login-password", "safe-password");
  await act(async () => container.querySelector("form").dispatchEvent(new Event("submit", { bubbles: true, cancelable: true })));
  expect(mockLogin).toHaveBeenCalledWith("alice", "safe-password", false);
});

test("auth dynamic user content remains intact inside translated English copy", async () => {
  await act(async () => root.render(<ForcePasswordChange />));

  expect(container.querySelector("h1").textContent).toBe("Change your password");
  expect(container.textContent).toContain("Signed in as alice.");
  expect(container.querySelector("section[dir=\"ltr\"]")).not.toBeNull();
  expect(container.querySelector('[data-testid="force-password-submit"]').textContent).toContain("Update password");
});
