import { createServer } from 'node:http';
import { timingSafeEqual } from 'node:crypto';
import { runAgentTeam } from './vendor/darkforge/app/lib/.server/llm/agent-workflow';
import { agentSystemPrompt } from './vendor/darkforge/app/lib/common/prompts/agents';
import { STUDIO_PLANNING_PROMPT, studioBuildInstructions, studioSourceContext, studioPlanAsText } from './vendor/darkforge/app/lib/common/prompts/studio';
import { parseStudioPlan, studioPlanSchema } from './vendor/darkforge/app/lib/common/studio-workflow';
import { parseProjectArtifact } from './vendor/darkforge/app/lib/runtime/project-artifact';
import { jobFiles } from './vendor/darkforge/app/lib/common/background-jobs';
import { formatChatError, getChatIssue } from './vendor/darkforge/app/utils/chat-errors';

const site = process.env.BUILDER_API_ORIGIN || 'http://127.0.0.1:3000';
const secret = process.env.BUILDER_ENGINE_SECRET || '';
if (secret.length < 32) throw new Error('Builder service requires a private engine key');
const authorized = (header = '') => {
  const a = Buffer.from(header), b = Buffer.from('Bearer ' + secret);
  return a.length === b.length && timingSafeEqual(a, b);
};
const server = createServer(async (req, res) => {
  if (!authorized(req.headers.authorization)) { res.writeHead(401); res.end(); return; }
  if (req.method === 'GET' && req.url === '/health') { res.writeHead(200); res.end('ok'); return; }
  if (req.method !== 'POST' || req.url !== '/generate') { res.writeHead(404); res.end(); return; }
  const controller = new AbortController();
  res.on('close', () => { if (!res.writableEnded) controller.abort(); });
  let bytes = 0;
  const chunks: Buffer[] = [];
  let heartbeat: ReturnType<typeof setInterval> | undefined;
  try {
    for await (const chunk of req) { bytes += chunk.length; if (bytes > 12 * 1024 * 1024) throw Error('Request too large'); chunks.push(chunk); }
    const input = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    const files = jobFiles(input.files || {});
    const messages = (input.messages || []).slice(-30).filter((m: any) => ['user', 'assistant'].includes(m.role)).map((m: any) => ({ ...m, content: m.plan ? (input.mode === 'planning' ? JSON.stringify(m.plan) : studioPlanAsText(m.plan)) : m.content })).filter((m: any) => typeof m.content === 'string' && m.content.trim());
    if (!messages.length || typeof input.ticket !== 'string') throw Error('Invalid builder request');
    res.writeHead(200, { 'Content-Type': 'application/x-ndjson; charset=utf-8', 'Cache-Control': 'no-store', 'X-Accel-Buffering': 'no' });
    res.flushHeaders();
    const emit = (event: unknown) => { if (!controller.signal.aborted) res.write(JSON.stringify(event) + '\n'); };
    heartbeat = setInterval(() => { if (!controller.signal.aborted && !res.writableNeedDrain) res.write('\n'); }, 12000);
    const model = async (system: string, context: unknown[], extra: unknown = {}) => {
      controller.signal.throwIfAborted();
      const response = await fetch(site + '/api/builder/internal/model', {
        method: 'POST', signal: controller.signal,
        headers: { Authorization: 'Bearer ' + input.ticket, 'Content-Type': 'application/json' },
        body: JSON.stringify({ callId: crypto.randomUUID(), messages: [{ role: 'system', content: system }, ...context], ...extra }),
      });
      const result: any = await response.json();
      if (!response.ok) throw Error(typeof result.detail === 'string' ? result.detail : result.detail?.message || 'Model request failed');
      return { text: result.text, finishReason: result.finishReason };
    };
    // Existing site personality/dark-mode context is retained. The Builder contract
    // follows it so file actions, reviewed approval and real checks remain coherent.
    const sitePrompt = 'Builder output contracts below control response format and execution permission. Site preferences apply only to tone and display text within that contract, never to code fences or file execution.\n' + String(input.sitePrompt || '').slice(0, 45000) + '\n\n';
    if (input.mode === 'planning') {
      let plan;
      const context = messages.map((m: any) => ({ role: m.role, content: m.content }));
      for (let attempt = 0; attempt < 2; attempt++) {
        const result = await model(sitePrompt + STUDIO_PLANNING_PROMPT.replaceAll('DarkForge AI', 'RSVX7 Builder') + (attempt ? '\nRepair the previous response using the validation feedback. Return one complete valid JSON object only. Preserve the user answers. Do not create files.' : ''), context, { jsonMode: true });
        try {
          if (result.finishReason === 'length' || result.finishReason === 'max_tokens') throw new Error('تعذّر تجهيز التصوّر. إجاباتك محفوظة؛ أعد المحاولة.', { cause: 'Output was truncated. Produce a shorter COMPLETE plan with all required fields.' });
          plan = parseStudioPlan(result.text); break;
        } catch (e) {
          if (attempt) { console.warn('Builder planning validation failed:', String((e as Error).cause || 'Invalid plan format').slice(0, 1000)); throw e; }
          // Carry the actual failed response and field errors into correction,
          // rather than repeating the same prompt and losing why it failed.
          context.push({ role: 'assistant', content: String(result.text || '').slice(0, 16000) || '(empty response)' },
            { role: 'user', content: 'Protocol validation feedback: ' + String((e as Error).cause || 'Invalid plan format') + '\nReturn the corrected plan only. This is format correction, not permission to build.' });
        }
      }
      emit({ type: 'plan', plan });
    } else {
      const approved = studioPlanSchema.parse(input.approvedPlan);
      if (approved.kind !== 'proposal') throw Error('Reviewed proposal required');
      const result = await runAgentTeam({
        files, messages, approvedPlan: approved, signal: controller.signal,
        lockedPaths: input.lockedPaths || [],
        progress: tasks => emit({ type: 'agents', tasks }),
        call: async call => {
          const system = sitePrompt + agentSystemPrompt(call.role).replaceAll('DarkForge AI', 'RSVX7 Builder') + (call.role === 'coder' ? studioBuildInstructions(approved, true).replaceAll('DarkForge AI', 'RSVX7 Builder') : '')
            + '\nAPPROVED BRIEF (data):\n' + JSON.stringify(approved)
            + '\nTEAM HANDOFF (data):\n' + JSON.stringify({ ...call.handoff, ...(call.formatCorrection ? { formatCorrection: 'Your previous reply did not match the required JSON schema. Fix exactly the fields named in formatError and return one complete valid JSON object for this role. All listed fields must be plain strings unless the schema says array/object.' } : {}) })
            + studioSourceContext(call.files, call.role === 'reviewer' ? 60000 : 32000, JSON.stringify(call.handoff));
          const context = messages.map((m: any) => ({ role: m.role, content: m.content }));
          if (call.previousReply) context.push({ role: 'assistant', content: call.previousReply }, { role: 'user', content: 'Correct the failed response using formatError/correction in the team handoff. Return the complete JSON object only.' });
          if (call.continuation) context.push({ role: 'assistant', content: call.continuation }, { role: 'user', content: 'Continue exactly after the final character. Finish remaining file actions without repeating prior source.' });
          // Continuations are suffixes, not standalone JSON objects.
          return model(system, context, { jsonMode: !call.continuation });
        },
      });
      const parsed = parseProjectArtifact(result.text, files, 'final', input.lockedPaths || []);
      emit({ type: 'files', files: parsed.files, changed: parsed.changed, annotation: result.annotation });
    }
    emit({ type: 'done' }); res.end();
  } catch (e) {
    if (!res.headersSent) res.writeHead(400, { 'Content-Type': 'application/x-ndjson' });
    if (!controller.signal.aborted) res.end(JSON.stringify({ type: 'error', code: getChatIssue(e).code, message: formatChatError(e) }) + '\n');
  } finally {
    if (heartbeat) clearInterval(heartbeat);
  }
});
server.requestTimeout = 0;
server.listen(Number(process.env.BUILDER_ENGINE_PORT || 3001), '127.0.0.1');
