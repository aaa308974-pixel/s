// Real workflow/parser regression tests; provider outputs are deterministic fixtures.
import { createRequire } from 'node:module';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import assert from 'node:assert/strict';
import { architecture, design, review, source, criteria } from './fixtures/agent-fixtures.mjs';
const require = createRequire(new URL('../frontend/package.json', import.meta.url));
const folder = await mkdtemp(join(tmpdir(), 'builder-protocol-'));
let checks = 0;
try {
  const root = resolve(new URL('..', import.meta.url).pathname);
  await require('esbuild').build({ stdin: { contents: `export { runAgentTeam } from './builder/vendor/darkforge/app/lib/.server/llm/agent-workflow'; export { parseProjectArtifact, projectArtifactText } from './builder/vendor/darkforge/app/lib/runtime/project-artifact';`, resolveDir: root }, bundle: true, platform: 'node', format: 'esm', target: 'es2022', outfile: join(folder,'protocol.mjs'), alias: {'~':join(root,'builder/vendor/darkforge/app')}, nodePaths:[join(root,'frontend/node_modules')], define:{'import.meta.env':'{}'} });
  const { runAgentTeam, parseProjectArtifact: parse, projectArtifactText: serialize } = await import(pathToFileURL(join(folder,'protocol.mjs')));
  const test = async (name, fn) => { await fn(); checks++; console.log('PASS', name); };
  const envelope = (names, overrides={}) => JSON.stringify({actions:names.map(filePath=>({type:'file',filePath,content:overrides[filePath] ?? source[filePath]}))});
  const assigned = call => call.handoff.batch?.files || Object.keys(source).slice(0,2);
  const batchEnvelope = call => JSON.stringify({actions:assigned(call).map(filePath=>({type:'file',filePath,content:source[filePath]})),remainingFiles:call.handoff.batch?[]:Object.keys(source).slice(2)});
  const run = async (custom, files={}, repairing=false) => {
    const tasks = [], calls = [], signal = new AbortController();
    const result = await runAgentTeam({files, messages:[{role:'user',content:repairing?'Repair preview: ReferenceError fixtureMissing is not defined at client.js:12':'Build items',...(repairing?{annotations:[{type:'studioRepair'}]}:{})}], approvedPlan:{acceptanceChecks:criteria}, signal:signal.signal,
      progress:value=>tasks.push(value), call: async call => {
        calls.push(call);
        const response = await custom?.(call, calls, signal);
        return response || {text:call.role==='coder'?batchEnvelope(call):JSON.stringify({architect:architecture,designer:design,reviewer:review}[call.role]),finishReason:'stop'};
      }});
    return { result, tasks, calls, files:parse(result.text,files,'final').files };
  };
  await test('direct implementation completes without planning or design calls and preserves every byte', async()=>{
    const result=await run(); for(const [name,content] of Object.entries(source))assert.equal(result.files['/home/project/'+name].content,content);
    assert.ok(result.result.annotation.tasks.every(task=>task.status==='completed'));
    assert.deepEqual(result.calls.map(call=>call.role),['coder','coder','coder','reviewer']);
    assert.ok(result.tasks.every(tasks=>tasks.every(task=>['coder','reviewer'].includes(task.role))));
    assert.ok(result.calls.filter(call=>call.role==='coder').every(call=>assigned(call).length<=2));
  });
  await test('JSON preserves Arabic, whitespace, entities, fences and delimiter literals',()=>{
    const content='  مرحبًا &lt;script&gt;\n```js\nconst tag="</boltAction>";\n```\n\n';
    const parsed=parse(envelope(['example.txt'],{'example.txt':content}),{},'one');
    assert.equal(parsed.files['/home/project/example.txt'].content,content);
    assert.equal(parse(serialize(parsed.files,parsed.changed,'two'),{},'two').files['/home/project/example.txt'].content,content);
  });
  await test('legacy XML preserves literal HTML entities',()=>{
    const parsed=parse('<boltArtifact id="a" title="a"><boltAction type="file" filePath="index.html">\n<p>&lt;script&gt;</p>\n</boltAction></boltArtifact>',{},'one');
    assert.equal(parsed.files['/home/project/index.html'].content,'<p>&lt;script&gt;</p>');
  });
  for(const [name,text] of [
    ['truncated source',envelope(['index.html']).slice(0,-3)],
    ['path traversal',envelope(['../secret'],{'../secret':'bad'})],
    ['shell execution',JSON.stringify({actions:[{type:'shell',content:'echo bad'}]})],
    ['duplicate paths',envelope(['index.html','index.html'])],
    ['second incomplete artifact','<boltArtifact id="a"><boltAction type="file" filePath="x">x</boltAction></boltArtifact><boltArtifact id="b">'],
  ]) await test('rejects '+name,()=>assert.throws(()=>parse(text,{},'invalid')));
  await test('locked files and binary assets remain untouched',()=>{
    assert.throws(()=>parse(envelope(['index.html']),{},'one',['index.html']));
    assert.throws(()=>parse(envelope(['index.html']),{'/home/project/index.html':{type:'file',content:'AA==',isBinary:true}},'one'));
  });
  await test('static architecture normalizes absent storage without weakening server contracts',async()=>{
    await run(call=>call.role==='architect'?{text:JSON.stringify({...architecture,data:{mode:'none'}}),finishReason:'stop'}:undefined,{},true);
    await assert.rejects(run(call=>call.role==='architect'?{text:JSON.stringify({...architecture,data:{mode:'server'}}),finishReason:'stop'}:undefined,{},true),/agent_format/);
  });
  await test('schema repair carries invalid reply and field feedback',async()=>{
    let attempts=0;
    await run(call=>{if(call.role==='designer'){
      attempts++;if(attempts===1)return {text:JSON.stringify({...design,palette:undefined}),finishReason:'stop'};
      assert.ok(call.previousReply.includes('direction'));assert.ok(call.handoff.formatError.includes('palette'));
    }}, {}, true);assert.equal(attempts,2);
  });
  for(const finish of ['length','max_tokens']) await test('continues '+finish+' at the exact source boundary',async()=>{
    let count=0, rest='';
    const result=await run(call=>{if(call.role==='coder' && count<2){count++;
      if(count===1){const raw=batchEnvelope(call);rest=raw.slice(173);return {text:raw.slice(0,173),finishReason:finish};}
      assert.ok(call.continuation);return {text:rest,finishReason:'stop'};
    }}); assert.equal(result.files['/home/project/server.mjs'].content,source['server.mjs']);
  });
  await test('continuation that restarts a full document does not concatenate documents',async()=>{
    let count=0;
    await run(call=>{if(call.role==='coder' && count++===0)return {text:batchEnvelope(call).slice(0,100),finishReason:'length'};});
  });
  await test('format repair has its own continuation budget',async()=>{
    let count=0, tail='';
    await run(call=>{if(call.role==='coder' && count<3){count++;
      if(count===1)return {text:'I built everything!',finishReason:'stop'};
      if(count===2){assert.ok(call.previousReply);assert.ok(call.handoff.correction);const raw=batchEnvelope(call);tail=raw.slice(160);return {text:raw.slice(0,160),finishReason:'length'};}
      return {text:tail,finishReason:'stop'};
    }});
  });
  await test('missing assigned file retries without committing a partial batch',async()=>{
    let count=0;
    await run(call=>{if(call.role==='coder' && call.handoff.batch && ++count===1)return {text:envelope(['index.html']),finishReason:'stop'};
      if(call.role==='coder' && count===2){assert.ok(!call.files['/home/project/index.html']);assert.match(call.handoff.correction,/Missing assigned/);}
    });
  });
  await test('malformed code invokes specialists with the actual error before a small-batch retry',async()=>{
    let bad=0, diagnostic;
    const result=await run(call=>{
      if(call.role==='coder' && bad++<2)return {text:'not file actions',finishReason:'stop'};
      if(call.role==='architect'){diagnostic=call.handoff.diagnostic;assert.equal(diagnostic.kind,'generation');assert.ok(diagnostic.message);}
      if(call.role==='designer')assert.deepEqual(call.handoff.diagnostic,diagnostic);
    });
    assert.deepEqual(result.calls.slice(0,4).map(call=>call.role),['coder','coder','architect','designer']);
    assert.ok(result.files['/home/project/server.test.mjs']);
  });
  await test('runtime diagnostics go to both specialists before implementation, preserving existing files',async()=>{
    const kept={'/home/project/keep.txt':{type:'file',content:'unchanged',isBinary:false}};
    const result=await run(call=>{if(['architect','designer'].includes(call.role)){
      assert.equal(call.handoff.diagnostic.kind,'runtime');assert.match(call.handoff.diagnostic.message,/fixtureMissing/);
      assert.equal(call.files['/home/project/keep.txt'].content,'unchanged');
    }},kept,true);
    assert.deepEqual(result.calls.slice(0,3).map(call=>call.role),['architect','designer','coder']);
    assert.equal(result.files['/home/project/keep.txt'].content,'unchanged');
  });
  await test('failed code review routes concrete defects to specialists and repairs before a fresh review',async()=>{
    let reviews=0;
    const result=await run(call=>{
      if(call.role==='reviewer' && reviews++===0)return {text:JSON.stringify({...review,verdict:'revise',issues:[{severity:'major',file:'client.js',problem:'Missing validation',fix:'Validate before submission'}]}),finishReason:'stop'};
      if(call.role==='architect' || call.role==='designer')assert.equal(call.handoff.diagnostic.review.issues[0].problem,'Missing validation');
    });
    assert.equal(reviews,2);assert.ok(result.result.annotation.tasks.every(task=>task.status==='completed'));
  });
  await test('malformed reviewer cannot be marked completed',async()=>{
    await assert.rejects(run(call=>call.role==='reviewer'?{text:'Looks good',finishReason:'stop'}:undefined),/agent_format/);
  });
  await test('genuine review failures cannot be silently salvaged',async()=>{
    await assert.rejects(run(call=>call.role==='reviewer'?{text:JSON.stringify({...review,verdict:'revise',issues:[{severity:'major',file:'server.mjs',problem:'Missing behavior',fix:'Implement behavior'}]}),finishReason:'stop'}:undefined),/agent_review/);
  });
  await test('provider failure is not retried as a format correction',async()=>{
    let count=0;await assert.rejects(run(call=>{if(call.role==='coder'){count++;throw Error('provider_unavailable');}}),/provider_unavailable/);assert.equal(count,1);
  });
  await test('cancellation after a model reply prevents committing candidate files',async()=>{
    await assert.rejects(run((call,calls,controller)=>{if(call.role==='coder')controller.abort();}),{name:'AbortError'});
  });
  console.log(`Builder protocol checks passed: ${checks}`);
} finally { await rm(folder,{recursive:true,force:true}); }
