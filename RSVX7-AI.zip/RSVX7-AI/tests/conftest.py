"""Never let regression fixtures bind to Manus's shared managed database.

MySQL integration tests construct their own repository against a loopback-only
SQL test server. Existing regressions use dedicated local Mongo fixtures.
"""
import os

os.environ["RSVX7_DATA_BACKEND"] = "mongo"
os.environ.pop("DATABASE_URL", None)
os.environ.pop("DRIZZLE_DATABASE_URL", None)
