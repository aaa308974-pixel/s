import { createContext, useContext, useEffect, useState } from 'react';
import { api } from '../lib/api';
const AuthContext=createContext(null);
export function AuthProvider({children}) {
 const [user,setUser]=useState(null),[loading,setLoading]=useState(true);
 useEffect(()=>{api.get('/auth/me').then(res=>setUser(res.data)).catch(()=>setUser(null)).finally(()=>setLoading(false));},[]);
 const logout=async()=>{
  const token=localStorage.getItem('rsvx7_token');
  try {await fetch('/api/auth/logout',{method:'POST',credentials:'same-origin',headers:token?{Authorization:'Bearer '+token}:{}});}
  finally {localStorage.removeItem('rsvx7_token');setUser(null);window.top.dispatchEvent(new Event('rsvx7:auth-expired'));window.top.location.href='/#login';}
 };
 return <AuthContext.Provider value={{user,setUser,loading,logout}}>{children}</AuthContext.Provider>;
}
export const useAuth=()=>useContext(AuthContext);
