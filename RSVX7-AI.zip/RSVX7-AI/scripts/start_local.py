#!/usr/bin/env python3
"""Bootstrap the full app locally, then configure a remote VPS in Admin."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import time

from init_selfhost import prepare

ROOT = Path(__file__).resolve().parents[1]


def launch(local_model=None):
    if not shutil.which('docker'):
        raise SystemExit('Install Docker Engine/Desktop with Compose, then run this launcher again.')
    if subprocess.run(['docker', 'compose', 'version'], stdout=subprocess.DEVNULL).returncode:
        raise SystemExit('Docker Compose is required.')
    if subprocess.run(['docker', 'info'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode:
        raise SystemExit('Start Docker Engine/Desktop, then run this launcher again.')
    environment = ROOT / 'private' / 'local.env'
    created = prepare(environment, {
        'siteUrl': 'http://localhost',
        'provider': 'local' if local_model else 'openrouter',
        'model': local_model,
    })
    if created:
        with environment.open('a') as file:
            file.write('HTTP_BIND=127.0.0.1\nHTTP_PORT=8080\nHTTPS_PORT=8443\n')
    settings = dict(line.split('=', 1) for line in environment.read_text().splitlines() if '=' in line)
    if local_model and settings.get('AI_PROVIDER') != 'local':
        raise SystemExit('An existing configuration was preserved. See OPERATIONS.txt to change provider safely.')
    command = ['docker', 'compose', '-p', 'rsvx7', '--env-file', str(environment),
               '-f', str(ROOT / 'deploy' / 'compose.selfhost.yaml')]
    if settings.get('AI_PROVIDER') == 'local':
        command += ['--profile', 'local']
    env = dict(os.environ, RSVX7_SELFHOST_ENV=str(environment), RSVX7_RELEASE_ID='local')

    def compose(*args, quiet=False):
        return subprocess.run(command + list(args), cwd=ROOT, env=env,
                              stdout=subprocess.DEVNULL if quiet else None,
                              stderr=subprocess.DEVNULL if quiet else None)

    print('Starting RSVX7 locally. Initial administrator credentials: private/local.env.', flush=True)
    for args in [('build', 'app'), ('up', '-d')]:
        result = compose(*args)
        if result.returncode:
            raise SystemExit(result.returncode)
    if settings.get('AI_PROVIDER') == 'local':
        result = compose('exec', '-T', 'ollama', 'ollama', 'pull', settings['LOCAL_MODEL_NAME'])
        if result.returncode:
            raise SystemExit('Local model download failed. Rerun this launcher to retry without resetting data.')
    probe = ('import urllib.request; urllib.request.urlopen("http://127.0.0.1:3000/readyz",timeout=4);'
             'urllib.request.urlopen("http://127.0.0.1:3000/",timeout=4)')
    for attempt in range(60):
        if compose('exec', '-T', 'app', 'python', '-c', probe, quiet=True).returncode == 0:
            print('Open http://localhost:8080 — Admin > Servers to configure your VPS.')
            return
        if attempt < 59:
            time.sleep(5)
    raise SystemExit('Application readiness failed. Check Docker, then rerun; configuration and volumes are preserved.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--local-model', help='Download and run this Ollama model on first setup, without an API key.')
    launch(parser.parse_args().local_model)


if __name__ == '__main__':
    main()
