"""Static-only compression. API/SSE bodies never pass through a gzip middleware."""
from pathlib import Path
from starlette.datastructures import Headers
from starlette.responses import FileResponse
from starlette.staticfiles import StaticFiles, NotModifiedResponse


def accepted_encodings(value: str):
    qualities = {}
    for item in value.lower().split(','):
        pieces = [piece.strip() for piece in item.split(';')]
        quality = 1.0
        for piece in pieces[1:]:
            if piece.startswith('q='):
                try: quality = float(piece[2:])
                except ValueError: quality = 0.0
        qualities[pieces[0]] = max(0.0, min(quality, 1.0))
    return sorted((encoding for encoding in ('br','gzip') if qualities.get(encoding, qualities.get('*',0)) > 0), key=lambda encoding: (-qualities.get(encoding, qualities.get('*',0)), 0 if encoding == 'br' else 1))


class CompressedStaticFiles(StaticFiles):
    async def get_response(self, path, scope):
        response = await super().get_response(path, scope)
        if response.status_code != 200 or not isinstance(response, FileResponse):
            return response
        response.headers['Cache-Control'] = 'public, max-age=31536000, immutable'
        response.headers['Vary'] = 'Accept-Encoding'
        headers = Headers(scope=scope)
        if not headers.get('range'):
            root = Path(self.directory).resolve()
            for encoding in accepted_encodings(headers.get('accept-encoding','')):
                candidate = Path(str(response.path) + ('.br' if encoding == 'br' else '.gz')).resolve()
                if candidate.is_relative_to(root) and candidate.is_file():
                    compressed = FileResponse(candidate, media_type=response.media_type, stat_result=candidate.stat(), method=scope['method'], headers={
                        'Content-Encoding': encoding,
                        'Cache-Control': response.headers['Cache-Control'],
                        'Vary': 'Accept-Encoding',
                    })
                    if self.is_not_modified(compressed.headers, headers):
                        return NotModifiedResponse(compressed.headers)
                    return compressed
        return response
