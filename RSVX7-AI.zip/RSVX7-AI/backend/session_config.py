"""Application signing configuration; never use the platform JWT alias in production."""
import os
import secrets
from collections.abc import Mapping

APP_SECRET_NAME = "RSVX7_JWT_SECRET"


def session_signing_secret(
    environ: Mapping[str, str] | None = None, *, require_configured: bool = False
) -> str:
    env = os.environ if environ is None else environ
    value = env.get(APP_SECRET_NAME)
    if value:
        if len(value) < 32 or value.startswith("REPLACE_") or not value.strip():
            raise RuntimeError(
                f"{APP_SECRET_NAME} must be a stable, random value of at least 32 characters"
            )
        return value
    if env.get("RSVX7_RUNTIME_ENV", "development").lower() == "production":
        raise RuntimeError(f"Required environment variable is missing: {APP_SECRET_NAME}")
    # Existing local development cookies and test fixtures must retain their key.
    legacy = env.get("JWT_SECRET")
    if legacy:
        if require_configured and (len(legacy) < 32 or legacy.startswith("REPLACE_")):
            raise RuntimeError("Development JWT_SECRET must be a stable value of at least 32 characters")
        return legacy
    if require_configured:
        raise RuntimeError(f"Required environment variable is missing: {APP_SECRET_NAME}")
    return secrets.token_hex(32)
